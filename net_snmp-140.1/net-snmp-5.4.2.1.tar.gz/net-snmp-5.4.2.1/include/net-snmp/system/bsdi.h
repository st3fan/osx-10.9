#include "bsd.h"

#define CHECK_RT_FLAGS 1
