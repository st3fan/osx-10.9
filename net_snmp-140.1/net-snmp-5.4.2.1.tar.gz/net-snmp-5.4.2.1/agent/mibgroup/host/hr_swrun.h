/*
 *  Host Resources MIB - Running Software group interface - hr_swrun.h
 *      (also includes Running Software Performance group )
 *
 */
#ifndef _MIBGROUP_HRSWRUN_H
#define _MIBGROUP_HRSWRUN_H

extern void     init_hr_swrun(void);
extern FindVarMethod var_hrswrun;


#endif                          /* _MIBGROUP_HRSWRUN_H */
