/*
 * smux.h: top level .h file to merely include the sub-module.
 */
config_require(smux/smux)
